# Sherish  eLearn
 E-Learning Platform using Java and odbc connectivity
